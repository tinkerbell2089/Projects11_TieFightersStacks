import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Stack;

public class TieFightersStacks {

	final static int MAXTieFighters = 10;
	static Stack<String> HangarA = new Stack<String>();
	static Stack<String> HangarB = new Stack<String>();	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		inputMethod();
		outputMethod();
	}
	
	public static void inputMethod(){
		
		File file = new File("tiefighters.txt");
		Scanner inputFile = null;
				
		try{			
			inputFile = new Scanner (file);
		}catch (FileNotFoundException e){
			e.printStackTrace();
		}
		
		while(inputFile.hasNextLine()){
			
			String Temp = inputFile.nextLine();
			String parts[] = Temp.split(" ");
			
			if (parts[0].equals("1")){ 
					push(parts[1]);
			}
				else if (parts[0].equals("2")){
					pop();
				}
				else popAll();
		}
	}
		
		public static void push(String string){
			
			if (HangarA.size() < MAXTieFighters){
				HangarA.push(string);
				System.out.println("Tie Fighter " + string + " has docked in Hangar A");
			}
			else if (HangarB.size() < MAXTieFighters){
				HangarB.push(string);
				System.out.println("Tie Fighter " + string + " has docked in Hangar B");
			}
			else
				System.out.println("Tie Fighter " + string + " has been rerouted to main hangar");
		}
		
		public static void pop(){

			if(!HangarA.isEmpty()){
				String string1 = HangarA.pop();
				System.out.println("Tie Fighter " + string1 + " has left Hangar A");
			}
			else if (!HangarB.isEmpty()){
				String string2 = HangarB.pop();
				System.out.println("Tie Fighter " + string2 + " has left Hangar B");
			}
			else 
				System.out.println("Command rerouted to main hangar");
			
		}
		
		public static void popAll(){
			
			if(HangarA.isEmpty() && HangarB.isEmpty())
				System.out.println("Bay is empty, command rerouted to main hangar bay");
			
			while (!HangarA.isEmpty()){
				String string1 = HangarA.pop();
				System.out.println("Tie Fighter " + string1 + " has left Hangar A");
			}
			while (!HangarB.isEmpty()){
				String string2 = HangarB.pop();
				System.out.println("Tie Fighter " + string2 + " has left Hangar B");
			}
		}
		
		public static void outputMethod(){		
			
			PrintWriter outputFile = null;
			
			try {
				outputFile = new PrintWriter ("hangarlog.txt");
				
			} catch (FileNotFoundException e) {			
				e.printStackTrace();
			}
			
			outputFile.print("Hangar A contains Tie Fighters:");
			
			while (!HangarA.isEmpty()){
				String string1 = HangarA.pop();
				outputFile.print(" " + string1);
			}
			
			outputFile.println();
			outputFile.print("Hangar B contains Tie Fighters:");
			while (!HangarB.isEmpty()){
				String string2 = HangarA.pop();
				outputFile.print(" " + string2);
			}
			
			outputFile.close();
		}
	}